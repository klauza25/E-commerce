from django.contrib import admin

from store.models import Commande, Panier, Product

# Register your models here.


admin.site.register(Product)
admin.site.register(Commande)
admin.site.register(Panier)