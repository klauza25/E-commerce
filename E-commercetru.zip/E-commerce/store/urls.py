from django.urls import path

from store.views import detail, index, ajouter



urlpatterns = [
    path('', index, name='index' ),
    path('details/<int:id>/', detail, name='detail'),
    path('details/<int:id>/ajoute_panier/', ajouter, name='ajouter'),
]
