from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Product(models.Model):

    nom = models.CharField(max_length=123)
    prix = models.FloatField(default=0.0)
    stock = models.IntegerField(default=0)
    description = models.TextField(blank=True)
    img = models.ImageField(upload_to="articlesImg", blank=True, null=True)

    def __str__(self):

        return self.nom
    

class Commande(models.Model):

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantite = models.IntegerField(default=1)
    commander = models.BooleanField(default=False)

    def __str__(self):

        return f"{self.product.nom} ({self.quantite})"
    

class Panier(models.Model):

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    commander = models.ManyToManyField(Commande)
    commandee = models.BooleanField(default=False)
    date_commande = models.DateField(blank=True, null=True)

    def __str__(self):

        return self.user.username