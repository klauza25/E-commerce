from django.shortcuts import redirect, render, get_object_or_404
from django.urls import reverse

from store.models import Product, Panier, Commande

# Create your views here.


def index(request):

    pro = Product.objects.all()


    return render(request, "store/index.html", {'pro': pro })


def detail(request, id):

    detail = Product.objects.get(id=id)


    return render(request, "store/detail.html", {'detail': detail })

def ajouter(request):

    user = request.user

    produit = get_object_or_404(Product, id=id)
    panier, _ = Panier.objects.get_or_create(user=user)
    commander, commandee = Commande.objects.get_or_create(user=user, produit=produit)


    if commandee:
        panier.commander.add(commander)
        panier.save()

    else:

        commander.quantite += 1
        commander.save()

    return redirect(reverse("detail",  kwargs={"id":id}))