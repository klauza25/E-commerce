from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
import re
# Create your views here.


def register(request):
    
    if request.method == 'POST':
        
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password2 = request.POST['password2']
        
        if password != password2:
            
            messages.error(request,"les deux mot de passe ne sont pas identiques ! ")
            
            return redirect('register')
        
        if len(password) < 6:
            
            messages.error(request,"le mot de passe est trop court utiliser au moin 6 au plus de caracteres ! ")
            
            return redirect('register')
        
        if not re.match(r'(?=.*[a-zA-Z])(?=.*\d)', password):
            
            messages.error(request,"le mot de passe doit contenir des chiffres et des lettres ! ")
            return redirect('register')
            
        if User.objects.filter(username=username):
            
            messages.error(request,"le nom d'utilisateur existe déjà ! ")
            
            return redirect('register')
            
        
        user = User.objects.create_user(username=username, email=email, password=password)
        
        user.save()
        return redirect('connexion')
        
    
    return render(request, 'compte/-register.html')




def connexion(request):
    
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(username = username, password = password )
        if  user is not None:
            login(request, user)
            username1 = user.username
            messages.success(request, 'vous vous etes connecter avec success ! ')
            return redirect('/')
           
        else:
            messages.error(request,"Mot de passe ou nom utilisateur incorrect")
            return redirect('connexion')
        
    return render(request, 'compte/-login.html')

def Deconnexion(request):
    logout(request)
    messages.success(request,"vous êtes déconnecter avec succes")
    return redirect('connexion')





