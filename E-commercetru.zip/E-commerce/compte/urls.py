from django.urls import path 
from .views import register, connexion, Deconnexion


urlpatterns = [
    path('register/', register, name='register'),
    path('', connexion, name='connexion'),
    path('logout', Deconnexion, name='logout')
]
